Giggity's Menu  (built on the Blaze starter menu)

Open: hold Y (left hand menu), touch buttons with your right index finger. < > flip pages.

NEW PAGES
 Main > Items > Item Index      browse every item the game has loaded, press one to pick it.
                                Spawn Item Gun / Spawn On Hand / Duplicate then use the picked item
                                (Clear Picked Item = back to "item in your left hand").
 Main > Mobs                    Mob Index (pick) + Mob Gun (right grip aims, trigger spawns). Max 12 per room, 1.5 s apart.
 Main > Soundboard              plays files from Android/data/com.TrassGames.Yeeps/files/sounds/  (.mp3 .wav .ogg .m4a)
                                Make the "sounds" folder yourself. Only you hear them. Volume + Stop buttons.
 Main > Paint                   Paint Gun (right grip aims, trigger paints) + Colour Palette = the 51 Yeeps paint brush colours.
 Movement                       + Super Jump (press B), Dash (press left trigger), Glide (hold B while falling)

BUILD:  ANDROID_NDK=/path/to/android-ndk-r27c ./build.sh   ->  out/giggitys-menu.so
INSTALL: drop the .so into Android/data/com.TrassGames.Yeeps/files/mods/ and restart Yeeps.
If something does nothing, open Android/data/com.TrassGames.Yeeps/files/bnm_checkpoint.txt, copy the lines starting with [mod] giggity: and send them.
