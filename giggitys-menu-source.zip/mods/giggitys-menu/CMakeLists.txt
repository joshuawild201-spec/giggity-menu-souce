add_yeeps_mod(giggitys-menu src/menu.cpp)
